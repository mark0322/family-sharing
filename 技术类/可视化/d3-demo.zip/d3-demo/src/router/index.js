import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/selection-dom',
    name: 'selection-dom',
    component: () => import('../views/selection-dom.vue')
  },
  {
    path: '/selection-svg',
    name: 'selection-svg',
    component: () => import('../views/selection-svg.vue')
  },
  {
    path: '/hierarchy-svg',
    name: 'hierarchy-svg',
    component: () => import('../views/hierarchy-svg.vue')
  },
  {
    path: '/hierarchy-canvas',
    name: 'hierarchy-canvas',
    component: () => import('../views/hierarchy-canvas.vue')
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
