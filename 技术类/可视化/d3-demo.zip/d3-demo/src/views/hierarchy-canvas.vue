<template>
  <div>
    <canvas width="800" height="800"></canvas>
  </div>
</template>

<script>
/* eslint-disable */
import { json } from 'd3-fetch'
import { hierarchy, pack } from 'd3-hierarchy'

const aColor = ['brown', 'cyan', 'steelblue']

export default {
  async mounted () {
    this._draw()
  },
  methods: {
    async _draw() {
      const canvas = document.querySelector('canvas')
      const ctx = canvas.getContext('2d')

      // ctx.fillStyle = 'red'
      // ctx.fillRect(100, 100, 200, 50)

      // ctx.arc(200, 200, 50, 0, 2 * Math.PI)
      // ctx.fill()

      const data = await json('/data/data.json')
      // console.log('data', data)

      const regions = hierarchy(data).sum(d => 1)
      // console.log('regions', regions)

      const _pack = pack().size([800, 800])(regions)
      console.log('_pack', _pack)

      ctx.globalAlpha = 0.3
      
      this._drawCircle(ctx, _pack)
    },

    _drawCircle(ctx, node) {
      const {x, y, r, depth} = node
      ctx.beginPath()
      ctx.arc(x, y, r, 0, 2 * Math.PI)
      ctx.fillStyle = aColor[depth]
      ctx.fill()

      if (node.children) {
        for (const node of node.children) {
          this._drawCircle(ctx, node)
        }
      }
    },









    // setup
    // async draw() {
    //   const canvas = document.querySelector('canvas')
    //   const ctx = canvas.getContext('2d')

    //   const data = await json('/data/data.json')
    //   console.log('data', data)

    //   const regions = hierarchy(data).sum(d => 1)
    //   console.log('regions', regions)

    //   const _pack = pack().size([800, 800]).padding(3)(regions)
    //   console.log('pack', _pack)

    //   ctx.globalAlpha = 0.3
    //   this.drawCircle(ctx, _pack)

    //   ctx.globalAlpha = 1
    //   ctx.textAlign = 'center'
    //   ctx.fillStyle = 'black'
    //   this.drawText(ctx, _pack)
    // },
    // drawCircle(ctx, {r, x, y, depth, children}) {
    //   ctx.beginPath()
    //   ctx.fillStyle = aColor[depth]
    //   ctx.arc(x, y, r, 0, Math.PI * 2)
    //   ctx.fill()

    //   if (Array.isArray(children)) {
    //     for (const data of children) {
    //       this.drawCircle(ctx, data)
    //     }
    //   }
    // },
    // drawText(ctx, {x, y, data, children}) {
    //   if (Array.isArray(children)) {
    //     for (const data of children) {
    //       this.drawText(ctx, data)
    //     }
    //   } else {
    //     ctx.fillText(data.name, x, y)
    //   }
    // }
  }
}
</script>

<style>
canvas {
  border: 1px solid black;
}
</style>