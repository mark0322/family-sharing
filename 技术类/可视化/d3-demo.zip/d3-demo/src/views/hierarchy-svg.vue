<template>
  <div>
    <svg>
      <g></g>
      <!-- <circle cx='200' cy='200' r='100' fill='red'></circle> -->
    </svg>
  </div>
</template>

<script>
/* eslint-disable */
import { json } from 'd3-fetch'
import { hierarchy, pack } from 'd3-hierarchy'
import { select } from 'd3-selection'

const aColor = ['brown', 'cyan', 'steelblue']

export default {
  mounted () {
    this.draw()
  },
  methods: {
    async draw() {
      const data = await json('/data/data.json')
      // console.log('data', data)

      const regions = hierarchy(data).sum(d => 1)
      // console.log('regions', regions)

      const _pack = pack().size([800, 800]).padding(3)(regions)
      console.log('pack', _pack)

      const g = select('svg g')

      this.drawCircle(g, _pack)
    },
    drawCircle(g, node) {
      const {x, y, r, depth, children} = node

      g.selectAll('circle')
        .data([node])
        .enter()
        .append('circle')
        .attr('cx', x)
        .attr('cy', y)
        .attr('r', r)
        .attr('fill', aColor[depth])

      if (Array.isArray(children)) {
        for (const node of children) {
          const g = select('svg').append('g')
          this.drawCircle(g, node)
        }
      }
    }
  }
}
</script>

<style>
svg {
  border: 1px solid black;
  width: 800px;
  height: 800px;
  opacity: 0.3;
}
</style>
