<template>
  <div>
    <ul id="list"></ul>
  </div>
</template>

<script>
/* eslint-disable */

// Q1: MVVM 是什么？
// Model(data) - View(DOM) -vm（Vue）

// Q2: MVVM 方便了哪些 DOM操作？
// 增、删、改

// import * as d3 from 'd3'
import { csv } from 'd3-fetch'
import { select } from 'd3-selection'

export default {
  async mounted () {
    // Q3: Data Drive Document 比 MVVM 有哪些优势?
    // 1,. 更底层
    // 2. 回掉函数

    const data = await csv('/data/msg.csv')
    console.log('data', data)

    const aLi = select('#list') // root
      .selectAll('li') // View
      .data(data) // Model
      .enter() // 增
      .append('li')

    console.log('aLi', aLi)

    aLi.text((item, i, nodeList) => {
      console.log('text', item, i, nodeList)
      return item.name
    })

    aLi.style('color', (d, i) => {
      return d.weight > 100
        ? 'red'
        : 'green'
    }).style('font-size', d => {
      return `${d.age}px`
    })














    // const lis = select('#list')
    //   .selectAll('li')
    //   .data(data)
    //   .enter()
    //   .append('li')

    // lis.append('span')
    //   .text(d => d.name)
    //   .style('color', d => {
    //     return d.weight > 100
    //       ? 'red'
    //       : 'green'
    //   })
    //   .style('font-size', d => {
    //     return d.age > 30
    //       ? '28px'
    //       : '20px'
    //   })

    // lis.append('span')
    //   .text(d => `性别: ${d.sex}`)
    //   .attr('class', 'sex-column')

    // const data2 = await csv('/data/msg-2.csv')
    // console.log('data2', data2)
    // select('#list')
    //   .selectAll('li')
    //   .data(data2)
    //   .enter()
    //   .append('li')
    //   .text(d => d.name)
    //   .style('color', 'blue')
  }
}
</script>

<style>
.sex-column {
  margin-left: 20px;
  font-size: 16px;
  color: teal;
}
</style>
