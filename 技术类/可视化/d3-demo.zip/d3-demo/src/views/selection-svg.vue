<template>
  <div>
    <svg>
      <!-- <rect x='100' y='100' width='50' height='50' fill='red'></rect> -->
      <!-- <text x="200" y='50'>哈哈</text> -->
    </svg>
  </div>
</template>

<script>
/* eslint-disable */
import { csv } from 'd3-fetch'
import { select } from 'd3-selection'
export default {
  async mounted () {
    const data = await csv('/data/msg.csv')
    console.log('data', data)

    select('svg') // root
      .selectAll('rect') // 
      .data(data)
      .enter()
      .append('rect')
      .attr('width', 50)
      .attr('y', 30)
      .attr('x', (d, i) => 100 * i)
      .attr('height', d => d.height)
      .attr('fill', d => d.weight > 100 ? 'red' : 'green')














    // select('svg')
    //   .selectAll('rect')
    //   .data(data)
    //   .enter()
    //   .append('rect')
    //   .attr('x', (d, i) => i * 50)
    //   .attr('y', 50)
    //   .attr('width', 40)
    //   .attr('height', d => d.height)
    //   .attr('fill', d => d.weight > 100 ? 'red' : 'green')

    // select('svg')
    //   .selectAll('text')
    //   .data(data)
    //   .enter()
    //   .append('text')
    //   .attr('x', (d, i, nodeList) => i * 50)
    //   .attr('y', 45)
    //   .text(d => d.name)
    //   .attr('font-size', '14px')
  }
}
</script>

<style>
svg {
  width: 800px;
  height: 400px;
  border: 1px solid black;
}
</style>
