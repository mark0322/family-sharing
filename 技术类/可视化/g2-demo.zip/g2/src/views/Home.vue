<template>
  <div class="home" id="chart">

  </div>
</template>

<script>
/* eslint-disable */
import * as d3 from 'd3';
import { Chart } from '@antv/g2';

export default {
  name: 'Home',
  async mounted () {
    const data = await d3.csv('/data/msg.csv');
    console.log('data', data)

    const chart = new Chart({
      container: 'chart',
      width: 600,
      height: 300
    });

    chart.data(data)

    chart.scale({
      weight: {
        type: 'linear'
      },
      height: {
        type: 'linear'
      },
      age:{
        type: 'linear'
      }
    });

    // chart.interval()
    //   .position('name*height')
    //   .color('weight', val => {
    //     return val > 100
    //       ? 'red'
    //       : 'green'
    //   })
    //   .size('age')

    chart.area()
      .position('name*height')

      chart.coordinate('polar')

    chart.render()

  }
}


function drawChart(data) {
    const chart = new Chart({
      container: 'chart',
      width: 600,
      height: 300
    });

    chart.data(data)

    chart.scale({
      weight: {
        type: 'linear'
      },
      height: {
        type: 'linear'
      },
      age:{
        type: 'linear'
      }
    })

    chart.area()
      .position('name*age')

    chart.coordinate('polar');
    
    chart.render()
}
</script>

<style scoped>
.home {
  width: 600px;
  height: 300px;
  border: 1px solid #cccccc;
}
</style>