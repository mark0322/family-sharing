<template>
  <div class="data-set" id="chart"></div>
</template>
<script>
/* eslint-disable */
import * as d3 from 'd3';
import { Chart } from '@antv/g2';
import { DataSet } from '@antv/data-set';

export default {
  name: 'DataSet',
  async mounted () {
    const data = await d3.csv('/data/msg.csv');
    console.log('data', data);

    const chart = new Chart({
      container: 'chart',
      width: 600,
      height: 300
    });

    const ds = new DataSet();
    const dv = ds.createView()
      .source(data)
      .transform({
        as: ['number'],
        groupBy: ['sex'],
        operations: ['count'],
        type: 'aggregate'
      });
    console.log('data-view', dv)

    chart.data(dv.rows)

    chart
      .interval()
      .adjust('stack')
      .color('sex')
      .position('number')


    chart.coordinate('theta')

    chart.render()
  }
}

function drawChart(data) {
    const chart = new Chart({
      container: 'chart',
      width: 600,
      height: 300
    });

    const ds = new DataSet();
    const dv = ds.createView()
      .source(data)
      .transform({
        as: ['number'],
        groupBy: ['sex'],
        operations: ['count'],
        type: 'aggregate'
      });

    console.log('dataView', dv);

    chart.data(dv.rows);

    chart
      .interval()
      .position('number')
      .adjust('stack')
      .color('sex')

    chart.coordinate('theta');
    
    chart.render()
}
</script>

<style>
.data-set {
  width: 600px;
  height: 300px;
  border: 1px solid #cccccc;
}
</style>